#include<iostream>
using namespace std;

int array[5], n = 5, front = - 1, rear = - 1;
void Insert()
{
    int i;
    for(i=0; i<6; i++){
   int val;
   if (rear == n - 1)
   cout<<"  array Overflow"<<endl ;
   else
    {
      if (front == - 1)
      front = 0;
      cout<<"   Insert the element in array : ";
      cin>>val;
      rear++;
      array[rear] = val;
   }
}

}
void Del()
{
    int pos;
    cout<< "Enter position element you want to delete 0-4 : ";
    cin>> pos;
   if (front == - 1 || front > rear)
   {
      cout<<"\n array Underflow ";
      return ;
   }
   else
   {
      cout<<"\n Element deleted from array is : "<< array[pos];
      front++;;
   }
}
void Disp()
{
   if (front == - 1)
   cout<<"array is empty"<<endl;
   else {
      cout<<"array elements are : ";
      for (int i = front; i <= rear; i++)
      cout<<array[i]<<" ";
         cout<<endl;
   }
}
int main()
{
   int ch;
   cout<<"\n 1) Insert element to array";
   cout<<"\n 2) Delete element from array";
   cout<<"\n 3) Display all the elements of array";
   cout<<"\n 4) Exit"<<endl;
   do
    {
      cout<<"\n Enter your choice : ";
      cin>>ch;
      switch (ch)
      {
         case 1: Insert();
         break;
         case 2: Del();
         break;
         case 3: Disp();
         break;
         case 4: cout<<" Exit"<<endl;
         break;
         default: cout<<" Invalid choice"<<endl;
      }
   } while(ch!=4);
   return 0;
}
