#include <iostream>
using namespace std;
int array[5], n =5, front = - 1, rear = - 1;
int i;
void Insert()
{
    for(i=0; i<6; i++){
   int val;
   if (rear == n - 1)
   cout<<"  array Overflow"<<endl ;
   else
    {
      if (front == - 1)
      front = 0;
      cout<<"   Insert the element in array : ";
      cin>>val;
      rear++;
      array[rear] = val;
   }
}
if (front == - 1)
   cout<<"  array is empty";
   else {
      cout<<"   array elements are : ";
      for (int i = front; i <= rear; i++)
      cout<<array[i]<<" ";
         cout<<endl;
   }
}

int main()
{
 Insert();

return 0;
}
