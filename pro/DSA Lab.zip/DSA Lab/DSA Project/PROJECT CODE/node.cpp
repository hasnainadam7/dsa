#include <iostream>
#include "node.h"

Node::Node(int data)
{
	this->data = data;      // is mein hum data ko data ke equal karen ge.
	this->next = NULL;      // is mein hum next ko null ke equal karen ge.
}
