#ifndef NODE_H
#define NODE_H

struct Node             
{
    Node* next;
    int data;

    Node(int data);

};
#endif