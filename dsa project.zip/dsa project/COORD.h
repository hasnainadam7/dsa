#ifndef MAIN_CPP_COORD_H
#define MAIN_CPP_COORD_H
#include <windows.h>

COORD coord;
void gotoxy (int x, int y);

#endif //MAIN_CPP_COORD_H
